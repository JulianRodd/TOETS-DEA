package nl.julian.controller;


import nl.julian.domain.Hallo;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/")
public class HelloWorldController {

    @GET
    @Path("en/")
    public String hello(){
            return "Hello world";
        }
    @GET
    @Path("nl/")
    public String hallo(){
        return "Hallo wereld";
    }
    @GET
    @Path("ob/")
    @Produces(MediaType.APPLICATION_JSON)
    public Hallo halloObject(){
        Hallo hallo = new Hallo();
        hallo.setHallo("Hallo");
        return hallo;
    }
    @GET
    @Path("rsp/")
    @Produces(MediaType.APPLICATION_JSON)
    public Response halloResponse(){
        Hallo hallo = new Hallo();
        hallo.setHallo("Hallo");
        Response myReponse = Response.status(403).entity(hallo).build();
        return myReponse;
    }
    @POST
    @Path("post/")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response postMaarData(Hallo bericht){
        System.out.println(bericht.getHallo());
        if("hallo".equals(bericht.getHallo())) {
            return Response.status(200).entity("Hello back").build();
        }else{
            return Response.status(503).entity("screw you").build();
        }
// Wat in de entity staat staat normaal gesproken in de domain laag.
    }
}
