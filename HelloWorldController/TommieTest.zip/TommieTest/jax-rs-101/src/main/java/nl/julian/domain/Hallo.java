package nl.julian.domain;

public class Hallo {
    private String hallo;
    public Hallo(){
    }

    public String getHallo() {
        return hallo;
    }

    public void setHallo(String hallo) {
        this.hallo = hallo;
    }
}
